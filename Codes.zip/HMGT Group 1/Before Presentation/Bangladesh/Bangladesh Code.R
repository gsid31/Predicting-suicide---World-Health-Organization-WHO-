#0.1 Setting the package : Install only if required
list.of.packages <- c("readr","modeest","corrplot","caret","PRROC","dplyr","rattle","nnet")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)

#0.2 Importing necessary Libraries
library(readr)
library(modeest)
library(corrplot)
library(caret)
library(PRROC)
library(rpart.plot)
library(rpart)
library(dplyr)
library(rattle)
library(nnet)
###############################################
###############################################
#Section 1 : Data cleaning process
#1.1 Reading the csv file in R
Bangladesh2014_National_Project <- read_csv("BGD2014_Public_Use.csv")

#1.1 Removed the columns that we arent using  
Bangladesh2014_National_Project<-Bangladesh2014_National_Project[,c(1:55)] 

#1.2 setting the categorical variables -> columns 19,21,46 dont exist so are not included below
colsToCategorical <- c('Q1','Q2','Q3','Q6','Q7','Q8','Q9','Q10','Q11','Q12','Q13','Q14','Q15'
                       ,'Q16','Q17','Q18','Q20','Q22','Q23','Q24','Q25','Q26','Q27'
                       ,'Q28','Q29','Q30','Q31','Q32','Q33','Q34','Q35','Q36','Q37','Q38','Q39',
                       'Q40','Q41','Q42','Q43','Q44','Q45','Q47','Q48','Q49','Q50','Q51','Q52',
                       'Q53','Q54','Q55','Q56','Q57','Q58')

Bangladesh2014_National_Project[,colsToCategorical] <- lapply(Bangladesh2014_National_Project[,colsToCategorical] , 
                                                        factor)

#1.3 The imputation process
#Replacing the numeric value with the median value for Q4 and Q5
colSums(is.na(Bangladesh2014_National_Project))
Bangladesh2014_National_Project <- Bangladesh2014_National_Project %>% 
  mutate_if(is.numeric, funs(replace(., is.na(.), median(., na.rm = TRUE))))

#1.4 The imputation process
#Replacing the factor value with the mode value for a particular column
Bangladesh2014_National_Project <- Bangladesh2014_National_Project %>% 
  mutate_if(is.factor, funs(replace(., is.na(.), mfv(., na_rm = T))))
colSums(is.na(Bangladesh2014_National_Project))

#1.5 Let us remove the columns which were completely empty - > no columns were empty
##Bangladesh2014_National_Project <- Bangladesh2014_National_Project[, !(names(Bangladesh2014_National_Project) %in% c("Q6","Q10","Q43"))]

#1.6 Outlier detection in  Q4 and Q5 columns
numeric_only_columns = c('Q4','Q5')
Bangladesh2014_National_Project_only_numeric <- Bangladesh2014_National_Project[ , (names(Bangladesh2014_National_Project) %in% numeric_only_columns)]

handling_outliers <- function(data){
  numeric_only_columns <- c('Q4','Q5')
  numeric_only_columns_len = length(numeric_only_columns)
  numberofRows = nrow(data)
  for (i in 1:numeric_only_columns_len){
    currentCol <- numeric_only_columns[i]
    Q1 <- quantile(data[[currentCol]], 0.25)
    Q3 <- quantile(data[[currentCol]], 0.75)
    
    IQR = Q3 - Q1
    upper_hinge_unemployment <- as.numeric(Q3 + 1.5 * IQR)[1]
    lower_hinge_unemployment <- as.numeric(Q1 - 1.5 * IQR)[1]
    
    data[currentCol] <- ifelse(
      data[[currentCol]] > upper_hinge_unemployment,
      upper_hinge_unemployment, 
      if_else
      (
        data[[currentCol]]  < lower_hinge_unemployment, 
        lower_hinge_unemployment , 
        data[[currentCol]]
      )
    )
  }
  return(data)
}
Bangladesh2014_National_Project <- handling_outliers(Bangladesh2014_National_Project)

#1.7
M <- cor(Bangladesh2014_National_Project_only_numeric)
corrplot(M, method = "number")

#1.8 Skewness in data
skewness(Bangladesh2014_National_Project$Q4)
skewness(Bangladesh2014_National_Project$Q5)


#1.9 : Removing the rows which are having nas in y variable

###############################################
###############################################
#section 2 : Creating 3 different dataset
bangladesh_considered_suicide <- Bangladesh2014_National_Project[, !(names(Bangladesh2014_National_Project) %in% c("Q25","Q26"))]
bangladesh_made_suicide <- Bangladesh2014_National_Project[, !(names(Bangladesh2014_National_Project) %in% c("Q24","Q26"))]
bangladesh_attempted_suicide <- Bangladesh2014_National_Project[, !(names(Bangladesh2014_National_Project) %in% c("Q24","Q25"))]

bangladesh_considered_suicide <- bangladesh_considered_suicide[!(is.na(bangladesh_considered_suicide$Q24)),]
###############################################
###############################################
#Section 3 : training and test data
#considered
set.seed(1000)
bangladesh_considered_suicide$Q24 <- ifelse(bangladesh_considered_suicide$Q24==2, 0, 1)
intrain<-createDataPartition(y= bangladesh_considered_suicide$Q24,p=0.7,list=FALSE)
training_set_considered_suicide <-bangladesh_considered_suicide[intrain,]
valid_set_considered_suicide <- bangladesh_considered_suicide[-intrain,]


#made
bangladesh_made_suicide$Q25 <- ifelse(bangladesh_made_suicide$Q25==2, 0, 1)
intrain<-createDataPartition(y= bangladesh_made_suicide$Q25,p=0.7,list=FALSE)
training_set_made_suicide  <-bangladesh_made_suicide[intrain,]
valid_set_made_suicide  <-bangladesh_made_suicide[-intrain,]


#attempted
bangladesh_attempted_suicide$Q26 <- ifelse(bangladesh_attempted_suicide$Q26==1, 0, 1)
intrain<-createDataPartition(y= bangladesh_attempted_suicide$Q26,p=0.7,list=FALSE)
training_set_attempted_suicide  <-bangladesh_attempted_suicide[intrain,]
valid_set_attempted_suicide  <-bangladesh_attempted_suicide[-intrain,]

###############################################
###############################################

#Section 4 : Model 1
#training_set_considered_suicide
#valid_set_considered_suicide


##logistic model
training_set_considered_suicide <- training_set_considered_suicide[, !(names(training_set_considered_suicide) %in% c("Q34","Q36","Q43","Q45"))]
valid_set_considered_suicide <- valid_set_considered_suicide[, !(names(valid_set_considered_suicide) %in% c("Q34","Q36","Q43","Q45"))]
model <- glm(Q24 ~ ., data=training_set_considered_suicide, family=binomial(link = "logit"))
prediction_model <- predict(model,newdata = valid_set_considered_suicide , type='response')
p <- ifelse(prediction_model > 0.5,2,1)
table(p, valid_set_considered_suicide$Q24)


PRROC_obj <- roc.curve(scores.class0 = prediction_model, 
                       weights.class0=valid_set_considered_suicide$Q24,curve=TRUE)
plot(PRROC_obj)
##above code gets an error

##Decision tree
dt_accuracy_depth <- data.frame(dataset=character(), depth = integer(),accuracy = integer(),stringsAsFactors=FALSE) 
for(i in 1:30) {
  decision_tree <- rpart(Q24 ~ ., data= training_set_considered_suicide, method = 'class',maxdepth = i)
  tree_model <- predict(decision_tree, newdata = training_set_considered_suicide, type='class')
  table_mat <- table(tree_model, training_set_considered_suicide$Q24)
  
  dt_accuracy_depth <- rbind(dt_accuracy_depth, data.frame(depth = i, accuracy = sum(diag(table_mat)) / sum(table_mat) , dataset = "training"))
  
}

for(i in 1:30) {
  decision_tree <- rpart(Q24 ~ ., data = training_set_considered_suicide, method = 'class',maxdepth = i)
  tree_model <- predict(decision_tree, newdata = valid_set_considered_suicide, type='class')
  table_mat <- table(tree_model, valid_set_considered_suicide$Q24)
  
  dt_accuracy_depth <- rbind(dt_accuracy_depth, data.frame(depth = i, accuracy = sum(diag(table_mat)) / sum(table_mat) ,dataset = "validation"))
  
}

ggplot(data = dt_accuracy_depth, aes(x=depth, y=accuracy)) + geom_line(aes(colour=dataset))


consider_tree<-rpart(Q24 ~ ., data = training_set_considered_suicide, method = 'class', maxdepth = 15)
prediction_tree_consider <-predict(consider_tree, newdata = valid_set_considered_suicide, type = 'class')
table_mat <- table(prediction_tree_consider,valid_set_considered_suicide$Q24)

#depth 1
###############################################
###############################################
#Section 5 : Model 2
#training_set_made_suicide
#valid_set_made_suicide

training_set_made_suicide <- training_set_made_suicide[, !(names(training_set_made_suicide) %in% c("Q34","Q36","Q43","Q45"))]
valid_set_made_suicide <- valid_set_made_suicide[, !(names(valid_set_made_suicide) %in% c("Q34","Q36","Q43","Q45"))]
#logistic Model
model2 <- glm(Q25 ~ ., data=training_set_made_suicide, family=binomial(link = "logit"))
prediction_model2 <- predict(model2,newdata = valid_set_made_suicide , type='response')
prediction_model2 <- ifelse(prediction_model2 > 0.5,1,0)
table(prediction_model2, valid_set_made_suicide$Q25)

PRROC_obj <- roc.curve(scores.class0 = prediction_model2, 
                       weights.class0=valid_set_made_suicide$Q25,curve=TRUE 
                       )
plot(PRROC_obj)

##decision Tree
dt_accuracy_depth <- data.frame(dataset=character(), depth = integer(),accuracy = integer(),stringsAsFactors=FALSE) 
for(i in 1:10) {
  decision_tree <- rpart(Q25 ~ ., data= training_set_made_suicide, method = 'class',maxdepth = i)
  tree_model <- predict(decision_tree, newdata = training_set_made_suicide, type='class')
  table_mat <- table(tree_model, training_set_made_suicide$Q25)
  
  dt_accuracy_depth <- rbind(dt_accuracy_depth, data.frame(depth = i, accuracy = sum(diag(table_mat)) / sum(table_mat) , dataset = "training"))
  
}

for(i in 1:10) {
  decision_tree <- rpart(Q25 ~ ., data = training_set_made_suicide, method = 'class',maxdepth = i)
  tree_model <- predict(decision_tree, newdata = valid_set_made_suicide, type='class')
  table_mat <- table(tree_model, valid_set_made_suicide$Q25)
  
  dt_accuracy_depth <- rbind(dt_accuracy_depth, data.frame(depth = i, accuracy = sum(diag(table_mat)) / sum(table_mat) ,dataset = "validation"))
  
}

ggplot(data = dt_accuracy_depth, aes(x=depth, y=accuracy)) + geom_line(aes(colour=dataset))
## decision tree graph is 2 straight lines so i dont know what depth to use

made_tree<-rpart(Q25 ~ ., data = training_set_made_suicide, method = 'class', maxdepth = 5)
prediction_tree_made <-predict(made_tree, newdata = valid_set_considered_suicide, type = 'class')
table_mat_made <- table(prediction_tree_consider,valid_set_made_suicide$Q25)

###############################################
###############################################
#Section 6 : Model 3
#training_set_attempted_suicide
#valid_set_attempted_suicide

#logistic model
training_set_attempted_suicide <- training_set_attempted_suicide[, !(names(training_set_attempted_suicide) %in% c("Q34","Q36","Q43","Q45","Q37","Q41"))]
valid_set_attempted_suicide <- valid_set_attempted_suicide[, !(names(valid_set_attempted_suicide) %in% c("Q34","Q36","Q43","Q45","Q37","Q41"))]

model3 <- glm(Q26 ~ ., data=training_set_attempted_suicide, family=binomial(link = "logit"))
prediction_model3 <- predict(model3,newdata = valid_set_attempted_suicide , type='response')
prediction_model3 <- ifelse(prediction_model3 > 0.5,1,0)
table(prediction_model3, valid_set_attempted_suicide$Q26)

PRROC_obj <- roc.curve(scores.class0 = prediction_model3, 
                       weights.class0=valid_set_attempted_suicide$Q26,curve=TRUE)

roc_(valid_set_attempted_suicide,prediction_model3,plot = TRUE)
plot(PRROC_obj)

#Decision Tree
dt_accuracy_depth <- data.frame(dataset=character(), depth = integer(),accuracy = integer(),stringsAsFactors=FALSE) 
for(i in 1:10) {
  decision_tree <- rpart(Q26 ~ ., data= training_set_attempted_suicide, method = 'class',maxdepth = i)
  tree_model <- predict(decision_tree, newdata = training_set_attempted_suicide, type='class')
  table_mat <- table(tree_model, training_set_attempted_suicide$Q26)
  
  dt_accuracy_depth <- rbind(dt_accuracy_depth, data.frame(depth = i, accuracy = sum(diag(table_mat)) / sum(table_mat) , dataset = "training"))
  
}

for(i in 1:10) {
  decision_tree <- rpart(Q26 ~ ., data = training_set_attempted_suicide, method = 'class',maxdepth = i)
  tree_model <- predict(decision_tree, newdata = valid_set_attempted_suicide, type='class')
  table_mat <- table(tree_model, valid_set_attempted_suicide$Q26)
  
  dt_accuracy_depth <- rbind(dt_accuracy_depth, data.frame(depth = i, accuracy = sum(diag(table_mat)) / sum(table_mat) ,dataset = "validation"))
  
}

ggplot(data = dt_accuracy_depth, aes(x=depth, y=accuracy)) + geom_line(aes(colour=dataset))

attempt_tree<-rpart(Q26 ~ ., data = training_set_attempted_suicide, method = 'class', maxdepth = 5)
prediction_tree_attempt <-predict(consider_tree, newdata = valid_set_attempted_suicide, type = 'class')
table_mat_attempt <- table(prediction_tree_attempt,valid_set_attempted_suicide$Q26)

###############################################
###############################################
#bangladesh_considered_suicide <- bangladesh_considered_suicide[, !(names(bangladesh_considered_suicide) %in% c("Q45"))]
bangladesh_considered_suicide$Q24 <- as.factor(bangladesh_considered_suicide$Q24)
#bangladesh_made_suicide <- bangladesh_made_suicide[, !(names(bangladesh_made_suicide) %in% c("Q45"))]
bangladesh_made_suicide$Q25 <- as.factor(bangladesh_made_suicide$Q25)
#bangladesh_attempted_suicide <- bangladesh_attempted_suicide[, !(names(bangladesh_attempted_suicide) %in% c("Q45"))]
bangladesh_attempted_suicide$Q26 <- as.factor(bangladesh_attempted_suicide$Q26)
##########################################

#Section 7 : Model 4
#training_set_attempted_suicide
#valid_set_attempted_suicide
bangladesh_National_Project_club_dependent <- Bangladesh2014_National_Project
bangladesh_National_Project_club_dependent$Q26 <- ifelse(
  bangladesh_National_Project_club_dependent$Q26==1,
                                                       1, 2)
bangladesh_National_Project_club_dependent$mergedAnswer <- NA

for(i in 1:nrow(bangladesh_National_Project_club_dependent)){
  if(bangladesh_National_Project_club_dependent$Q24[i] == 1 & 
     bangladesh_National_Project_club_dependent$Q25[i] == 1 &
     bangladesh_National_Project_club_dependent$Q26[i] == 1)
  {
    bangladesh_National_Project_club_dependent$mergedAnswer[i] <- 0
  }
  else if(bangladesh_National_Project_club_dependent$Q26[i] == 2)
  {
    bangladesh_National_Project_club_dependent$mergedAnswer[i] <- 3
  }
  else if(bangladesh_National_Project_club_dependent$Q25[i] == 1)
  {
    bangladesh_National_Project_club_dependent$mergedAnswer[i] <- 2
  }
  else if(bangladesh_National_Project_club_dependent$Q24[i] == 1)
  {
    bangladesh_National_Project_club_dependent$mergedAnswer[i] <- 1
  }
  
}

bangladesh_National_Project_club_dependent$mergedAnswer <- factor(bangladesh_National_Project_club_dependent$mergedAnswer)



bangladesh_National_Project_club_dependent <- 
  bangladesh_National_Project_club_dependent[, !(names(bangladesh_National_Project_club_dependent) %in% c("Q24","Q25","Q26"))]

bangladesh_National_Project_club_dependent <- bangladesh_National_Project_club_dependent[, !(names(bangladesh_National_Project_club_dependent) %in% c("Q34","Q36","Q43","Q45","Q37","Q41"))]

bangladesh_National_Project_club_dependent <- downSample(
  x = bangladesh_National_Project_club_dependent[, -ncol(bangladesh_National_Project_club_dependent)],
  y = bangladesh_National_Project_club_dependent$mergedAnswer)


intrain<-createDataPartition(y= bangladesh_National_Project_club_dependent$Class,
                             p=0.7,list=FALSE)
training_set_suicide_seriousness  <-bangladesh_National_Project_club_dependent[intrain,]
valid_set_suicide_seriousness  <-bangladesh_National_Project_club_dependent[-intrain,]



test <- multinom(Class ~ ., data = training_set_suicide_seriousness, MaxNWts = 1000000)

prediction_model2 <- predict(test,newdata = valid_set_suicide_seriousness , type='class')
table(prediction_model2, valid_set_suicide_seriousness$Class)

