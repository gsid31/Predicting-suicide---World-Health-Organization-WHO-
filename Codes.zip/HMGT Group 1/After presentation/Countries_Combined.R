#0.1 Setting the package : Install only if required
list.of.packages <- c("readr","modeest","corrplot","caret","PRROC","dplyr","rattle","RGtk2")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)

#0.2 Importing necessary Libraries
library(readr)
library(modeest)
library(corrplot)
library(caret)
library(PRROC)
library(rpart.plot)
library(rpart)
library(dplyr)
library(rattle)
library(RGtk2)
###############################################
###############################################
#Section 1 : Data cleaning process
#1.1 Reading the csv file in R
Countries_Combined <- read_csv("Countries_Combined.csv")

#1.2 Converting the columns to categorical
colsToCategorical <- c("Q1","Q2","Q3","Q7","Q8","Q9","Q11","Q12","Q13","Q14","Q15","Q16",
                       "Q17","Q20",  "Q22","Q23","Q24","Q25","Q26","Q27","Q32","Q33","Q34",
                       "Q35","Q36","Q37", "Q38","Q39","Q40","Q49","Q50","Q51","Q52",
                       "Q53","Q54","Q55","Q56","Q57","Q58")

Countries_Combined[,colsToCategorical] <- lapply(Countries_Combined[,colsToCategorical] , 
                                                       factor)


#1.2 The imputation process
#Replacing the numeric value with the median value for Q4 and Q5
colSums(is.na(Countries_Combined))
Countries_Combined <- Countries_Combined %>% 
  mutate_if(is.numeric, funs(replace(., is.na(.), median(., na.rm = TRUE))))

#1.3 The imputation process
#Replacing the factor value with the mode value for a particular column
Countries_Combined <- Countries_Combined %>% 
  mutate_if(is.factor, funs(replace(., is.na(.), mfv(., na_rm = T))))
colSums(is.na(Countries_Combined))

#1.4 Outlier detection in  Q4 and Q5 columns
numeric_only_columns = c('Q4','Q5')
Countries_Combined_only_numeric <- Countries_Combined[ , (names(Countries_Combined) %in% numeric_only_columns)]


handling_outliers <- function(data){
  numeric_only_columns <- c('Q4','Q5')
  numeric_only_columns_len = length(numeric_only_columns)
  numberofRows = nrow(data)
  for (i in 1:numeric_only_columns_len){
    currentCol <- numeric_only_columns[i]
    Q1 <- quantile(data[[currentCol]], 0.25)
    Q3 <- quantile(data[[currentCol]], 0.75)
    
    IQR = Q3 - Q1
    upper_hinge_unemployment <- as.numeric(Q3 + 1.5 * IQR)[1]
    lower_hinge_unemployment <- as.numeric(Q1 - 1.5 * IQR)[1]
    
    data[currentCol] <- ifelse(
      data[[currentCol]] > upper_hinge_unemployment,
      upper_hinge_unemployment, 
      if_else
      (
        data[[currentCol]]  < lower_hinge_unemployment, 
        lower_hinge_unemployment , 
        data[[currentCol]]
      )
    )
  }
  return(data)
}
Countries_Combined <- handling_outliers(Countries_Combined)


#1.5
M <- cor(Countries_Combined_only_numeric)
corrplot(M, method = "number")

#1.6 Skewness in data
skewness(Countries_Combined$Q4)
skewness(Countries_Combined$Q5)

#1.7 Removing the country column
Countries_Combined <- Countries_Combined[ , !(names(Countries_Combined) %in% c("Country"))]

#1.8 Creating the dependent variable
Countries_Combined$comb_value <- NA
Countries_Combined$comb_value <- ifelse(Countries_Combined$Q24==2 &
                                          Countries_Combined$Q25==2 &
                                          Countries_Combined$Q26==1
                                          , 0, 1)

Countries_Combined <- Countries_Combined[ , !(names(Countries_Combined) %in% 
                                                c("Q24","Q25","Q26"))]


#1.9 Building train and test data
set.seed(100)
intrain<-createDataPartition(y= Countries_Combined$comb_value,p=0.7,list=FALSE)
training_set_suicide  <-Countries_Combined[intrain,]
valid_set_suicide  <-Countries_Combined[-intrain,]

#Section 2 Running the logistic model with all variables - no downsampling
model <- glm(comb_value ~ .
               ,
             data=training_set_suicide, family=binomial(link = "logit"))
prediction_model <- predict(model,newdata = valid_set_suicide , type='response')
p <- ifelse(prediction_model > 0.5,1,0)
table(p, valid_set_suicide$comb_value)



PRROC_obj <- roc.curve(scores.class0 = prediction_model, 
                       weights.class0=valid_set_suicide$comb_value,curve=TRUE)
plot(PRROC_obj)


#Section 3 Running the logistic model with important variables - no down sampling
model <- glm(comb_value ~ Q15+Q16+Q17+
               Q20+Q22+Q23+Q27+Q32+
               Q33+Q34+Q35+Q36+Q37+
               Q38+Q39+Q40+Q49+Q54+Q56+Q58
             ,
             data=training_set_suicide, family=binomial(link = "logit"))
prediction_model <- predict(model,newdata = valid_set_suicide , type='response')
p <- ifelse(prediction_model > 0.5,1,0)
table(p, valid_set_suicide$comb_value)



PRROC_obj <- roc.curve(scores.class0 = prediction_model, 
                       weights.class0=valid_set_suicide$comb_value,curve=TRUE)
plot(PRROC_obj)


#Section 4 Running the logistic model with all variables - down sampling
Countries_Combined_down_sample <- Countries_Combined
Countries_Combined_down_sample$comb_value <- as.factor(Countries_Combined_down_sample$comb_value)
Countries_Combined_down_sample <- downSample(
  x = Countries_Combined_down_sample[, -ncol(Countries_Combined_down_sample)],
  y = Countries_Combined_down_sample$comb_value)

Countries_Combined_down_sample$Class <- as.numeric(Countries_Combined_down_sample$Class)
Countries_Combined_down_sample$Class  <- ifelse(
  Countries_Combined_down_sample$Class == 2,1,0)
intrain<-createDataPartition(y= Countries_Combined_down_sample$Class,p=0.7,list=FALSE)

training_set_suicide  <-Countries_Combined_down_sample[intrain,]
valid_set_suicide  <-Countries_Combined_down_sample[-intrain,]

model <- glm(Class ~ .,
             data=training_set_suicide, family=binomial(link = "logit"))
prediction_model <- predict(model,newdata = valid_set_suicide , type='response')
p <- ifelse(prediction_model >= 0.5,1,0)
table(p, valid_set_suicide$Class)



PRROC_obj <- roc.curve(scores.class0 = prediction_model, 
                       weights.class0=valid_set_suicide$Class,curve=TRUE)
plot(PRROC_obj)

#Section 5 Running the logistic model with important variables - downsampling
model <- glm(Class ~ Q15+Q16+Q17+
               Q20+Q22+Q23+Q27+Q32+
               Q33+Q34+Q35+Q36+Q37+
               Q38+Q39+Q40+Q49+Q54+Q56+Q58,
             data=training_set_suicide, family=binomial(link = "logit"))
prediction_model <- predict(model,newdata = valid_set_suicide , type='response')
p <- ifelse(prediction_model >= 0.5,1,0)
table(p, valid_set_suicide$Class)

PRROC_obj <- roc.curve(scores.class0 = prediction_model, 
                       weights.class0=valid_set_suicide$Class,curve=TRUE)
plot(PRROC_obj)

#for rattle
Countries_Combined$comb_value <- as.factor(Countries_Combined$comb_value)
Countries_Combined_down_sample$Class <- as.factor(Countries_Combined_down_sample$Class)